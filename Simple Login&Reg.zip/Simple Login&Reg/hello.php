<?php
$host="localhost";
$username="root";
$password="";
$db_name="school";


$conn= mysqli_connect($host,$username,$password,$db_name);


if(mysqli_connect_errno()){
die("failed to connect :".mysqli_connect_error());

}else{
echo"login successful";
}
?>
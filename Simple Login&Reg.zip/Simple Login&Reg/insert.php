<?php

require_once("connection.php");

if((isset($_POST['username']) && $_POST['password']))
{


$username = $conn->real_escape_string($_POST['username']);
$password = $conn->real_escape_string($_POST['password']);



$sql="insert into login(username,password) values(if(isset($_POST)['username'],$_POST['password'])";

mysql_close($conn);
}
?>
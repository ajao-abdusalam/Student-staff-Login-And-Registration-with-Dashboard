<?php
include('connection.php');
    ?>
<html>
    <head>
        <link rel="stylesheet" href="style_signup.css" type="text/css">
        <script>
            function validateForm()
            {
                a=document.forms["register-form"]["first_name"].value;
                b=document.forms["register-form"]["second_name"].value;
                c=document.forms["register-form"]["last_name"].value;
                d=document.forms["register-form"]["e_mail"].value;
                e=document.forms["register-form"]["password"].value;

                if(a==null || a=="")
                {
                    alert("First name cannot be empty");
                    return false;
                }
                if(b==""){
                    alert("Second name cannot be empty");
                    return false;
                }
                if(c==""){
                    alert("last name cannot be empty");
                    return false;
                }
                if(d==""){
                    alert("email  cannot be empty");
                    return false;
                }
                if(e==""){
                    alert("password cannot be empty");
                    return false;
                }
               

            }
            </script>
        </head>

        <body>
            <div class="form">
                <div class="form-header">
                    <h2>Registration Form</h2>
                </div>
            
            <div class="main-form">
                <br>
                <form method="post" action="" name="register-form" onsubmit="return validateForm()">
                    
                    <label>Firstname</label>
                    <input type="text"  name="first_name" >
    <br>
    <br>
                    <label>Secondname</label>
                    <input type="text" name="second_name" >

    <br>
    <br>

                    <label>Lastname</label>
                    <input type="text" name="last_name" >
    <br>
    <br>

                    <label>Email</label>
                    <input type="text" name="e_mail" >

    <br>
    <br>
    
                    <label>Enter Password</label>
                    <input type="password" name="password" id="password" onkeyup='check();'/> 

    <br>
    <br>
    
                    <label>Re-enter Password</label>
                    <input type="password" name="confirm_password" id="confirm_password"  onkeyup='check();'/>
    <br>
    <br>
    <div class="show">
    <span id='message'></span>
        </div>
    
                    <input type="submit" class="sub" value="Register">
                    </form>

                    <script src="checkpassword.js"></script>

                    <div class="footer"
                        <h2>Already have an account....</h2><a href="login1.php">Login</a>
                    </div>
                </div>
                                                          
                

                
                    
                    </div>
            </body>

    </html>
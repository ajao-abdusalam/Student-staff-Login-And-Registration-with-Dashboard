<?php
include('connection.php');

if (isset($_POST['submit']))
{
    //variables declarations for input field with security
    $Username=mysqli_real_escape_string($conn, $_POST['username']);
    $Password=mysqli_real_escape_string($conn, $_POST['password']);
    
     
    $query="SELECT * FROM `login` WHERE username ='$Username' AND Password ='$Password'";
    $result= mysqli_query($conn,$query);
    $rows=mysql_num_rows($result);

    if($Rows > 0)
    {
        echo "<script>alert('login successful');</script>";
    }
    else{
        echo "<script>alert('invalid login credential, please try again');</script>";
    }
}


?>
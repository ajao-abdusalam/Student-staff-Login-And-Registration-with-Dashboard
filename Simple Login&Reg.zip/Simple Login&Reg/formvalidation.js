function validateForm(){
    var username=document.forms["login-form"]["Username"];
    var password=document.form["login-form"]["Password"];

    if(username.value=""){
        window.alert("please enter username");
        username.focus();
        return false;
    }

     if(password.value=""){
        window.alert("please enter password");
        username.focus();
        return false;
    }
    return true;
}


<!--- 
a=document.forms["register-form"]["first_name"].value;
 b=document.forms["register-form"]["second_name"].value;
 c=document.forms["register-form"]["last_name"].value;
 d=document.forms["register-form"]["e_mail"].value;
 e=document.forms["register-form"]["pass_word"].value;
 f=document.forms["register-form"]["pass_word1"].value;



 if(a.value=="")
 {
     alert("First name cannot be empty");
     a.focus();
     return false;
 }
 if(b.value==""){
     alert("Second name cannot be empty");
     b.focus();
     return false;
 }
 
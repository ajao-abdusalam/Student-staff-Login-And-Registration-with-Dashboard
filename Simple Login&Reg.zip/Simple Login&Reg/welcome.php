<?php
include('connection.php');
session_start();
if(!isset($_SESSION['Username'])){
header("location:login1.php");
}
?>

<html>
    <body>
        <h5>welcome<?php echo $_SESSION?></h5>
</body>
    </html>
<?php
include("connection.php");
    ?>
<html>
    <head>
        <link rel="stylesheet" href="style.css" type="text/css">
        <script>
            function validateForm()
            {
                x=document.forms["login-form"]["username"].value;
                y=document.forms["login-form"]["password"].value;

                if(x==null || x=="")
                {
                    alert("Username cannot be empty");
                    return false;
                }
                if(y==""){
                    alert("password cannot be empty");
                    return false;
                }
                else if(y.length <7)
                {
                    alert("password cannot be less than 7 characters");
                    return false;
                }

            }
            </script>
        </head>

        <body>
            <div class="form">
                <div class="form-header">
                    <h2>Login Form</h2>
                </div>
            
            <div class="main-form">
                <br>
                <form method="post" action="insert.php" name="login-form" onsubmit="return validateForm()">
                    
                    <label>Username</label>
                    <input type="text"  name="username" >
    <br>
    <br>
                    <label>Password</label>
                    <input type="password" name="password" >
    <br>
    <br>
    
                    <input type="submit" class="sub" value="Login">
                    </form>

                    <div class="footer"
                        <h2>Dont have an account....</h2><a href="signup.php">Register</a>
                    </div>
                </div>
                                                          
                

                
                    
                    </div>
            </body>

    </html>